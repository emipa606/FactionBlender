﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FactionBlender")]
[assembly: AssemblyDescription("Create a mixed race faction")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("FactionBlender")]
[assembly: AssemblyCopyright("Copyright © SineSwiper, Artistic 2.0")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("5e005136-e676-482b-95b7-c12a03d5e683")]

[assembly: AssemblyVersion("1.4.2")]
[assembly: AssemblyFileVersion("1.4.2")]
